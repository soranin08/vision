package com.example.visiontest

import android.Manifest.permission.RECORD_AUDIO
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.widget.ImageView
import kotlinx.coroutines.delay
import kotlin.random.Random
import java.util.*
import kotlin.concurrent.thread
import kotlin.concurrent.timerTask


class MainActivity : AppCompatActivity() {

    private lateinit var startBotton: Button
    private lateinit var sampletext: TextView
    private lateinit var randle_img: ImageView

    private val imageResources = listOf(
        R.drawable.dw,
        R.drawable.le,
        R.drawable.ri,
        R.drawable.up
    )

    private val answerkanji = listOf(
        "下",
        "左",
        "右",
        "上"
    )
    private val answerhiragana = listOf(
        "した",
        "ひだり",
        "みぎ",
        "うえ"
    )

    private var currentIndex = 0

    private var num = 0

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        randle_img = findViewById(R.id.imageView)
        startBotton = findViewById(R.id.recognize_start_button)
        sampletext = findViewById(R.id.recognize_text_view)

        startBotton.setOnClickListener{
            startBotton.visibility = View.INVISIBLE
            randle_img.setImageResource(imageResources[num])
            randle_img.visibility = View.VISIBLE
            displaySpeechRecognizer()
        }
    }
    val SPEECH_REQUEST_CODE = 0
    
    // Create an intent that can start the Speech Recognizer activity
    private fun displaySpeechRecognizer() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        }
        // This starts the activity and populates the intent with the speech text.
        startActivityForResult(intent, SPEECH_REQUEST_CODE)
        Log.d("DEBUG","startActivityForResult 実行後")
    }


    // This callback is invoked when the Speech Recognizer returns.
// This is where you process the intent and extract the speech text from the intent.
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        Log.d("DEBUG","point A")

        if (requestCode == SPEECH_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            Log.d("DEBUG","point B")

//            Handler().postDelayed({
//                sampletext
//            }, 1000)

            Log.d("DEBUG","point C")
            val spokenText: String? =
                data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.let { results ->
                    results[0]
                }

            Log.d("DEBUG","point D")
            // Do something with spokenText.

            if(answerkanji[num] == spokenText || answerhiragana[num] == spokenText){
                sampletext.setText("正解")
                Log.d("DEBUG","正解")
            }else{
                sampletext.text = "不正解"
                Log.d("DEBUG","不正解")
            }
            Log.d("DEBUG","point E")
            num++
            randle_img.setImageResource(imageResources[num])
            Thread.sleep(3000)
            // 音声認識を起動
            displaySpeechRecognizer()

        }
//        super.onActivityResult(requestCode, resultCode, data)
    }

    companion object{
        private const val PERMISSION_RECORD_AUDIO = 1000
    }
}
