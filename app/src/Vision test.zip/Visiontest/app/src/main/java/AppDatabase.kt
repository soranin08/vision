//package com.example.visiontest
//
//import androidx.room.Database
//import androidx.room.RoomDatabase
//
//class AppDatabase {
//    @Database(entities = [PlayCallEntity::class], version = 1)
//    abstract class AppDatabase : RoomDatabase(){
//        abstract fun playCallDao(): PlayCallEntity.PlayCallDao
//    }
//}